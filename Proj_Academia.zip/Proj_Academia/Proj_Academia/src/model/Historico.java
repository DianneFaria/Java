package model;


public class Historico {
	private String cpf;
	private String dataHistorico;
	private String peso;
	private int id;
	
	public Historico(int id, String peso, String dataHistorico) {
		super();
		this.dataHistorico = dataHistorico;
		this.peso = peso;
		this.id = id;
	}
	


	public Historico(int id) {
		super();
		this.id = id;
	}


	public Historico(String cpf, String dataHistorico, String peso) {
		super();
		this.cpf = cpf;
		this.dataHistorico = dataHistorico;
		this.peso = peso;
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getDataHistorico() {
		return dataHistorico;
	}
	public void setDataHistorico(String dataHistorico) {
		this.dataHistorico = dataHistorico;
	}
	public String getPeso() {
		return peso;
	}
	public void setPeso(String peso) {
		this.peso = peso;
	}
	
	
	
}
