package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import model.Aluno;
import model.Historico;





public class UsuarioDao { 
	
	
	private final Connection connection;

	public UsuarioDao(Connection connection) throws SQLException {
        this.connection = new Conexao().getConnection();
    }
	
	public void insert(Aluno aluno) throws SQLException {
		
		String sql = "insert into cadastro(nome, cpf, dataNascimento, peso, altura) values(?,?,?,?,?);";
				
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, aluno.getNome());
		statement.setString(2, aluno.getCpf());
		statement.setString(3, aluno.getDataNascimento());
		statement.setString(4, aluno.getPeso());
		statement.setString(5, aluno.getAltura());
		statement.execute();		
	}
	
	public void insertHistorico(Historico historico) throws SQLException {
			
			String sql = "insert into historico(cpf, peso, dataHistorico) values(?,?,?);";
					
			PreparedStatement statement = connection.prepareStatement(sql);
			
			statement.setString(1, historico.getCpf());		
			statement.setString(2, historico.getDataHistorico());
			statement.setString(3, historico.getPeso());
			statement.execute();		
		}
	
	public void update (Aluno aluno) throws SQLException {
		
		String sql = "update cadastro set nome = ?, cpf = ?, dataNascimento = ?, peso = ?, altura = ? where cpf = ?";
		
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, aluno.getNome());
		statement.setString(2, aluno.getCpf());
		statement.setString(3, aluno.getDataNascimento());
		statement.setString(4, aluno.getPeso());
		statement.setString(5, aluno.getAltura());
		statement.setString(6, aluno.getCpf());
		statement.execute();
	}
	
	public void updateHistorico (Historico historico) throws SQLException {
			
			String sql = "update historico set id = ?, peso = ?, dataHistorico = ? where id = ?";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, historico.getId());
			statement.setString(2, historico.getPeso());
			statement.setString(3, historico.getDataHistorico());
			statement.setInt(4, historico.getId());
			statement.execute();
		}
	
	
	public void insertOrUpdate(Aluno aluno) throws SQLException {
		if(aluno.getCpf().equals(null)) {
			insert(aluno);
		}
		else {
			update(aluno);
		}
	}
	
	public void delete(Aluno aluno) throws SQLException{
		
		String sql = "delete from cadastro where cpf = ?";
		PreparedStatement statement = connection.prepareStatement(sql);
		
		statement.setString(1, aluno.getCpf());
		statement.execute();
	}
	
	public void deleteHistorico(Historico historico) throws SQLException{
			
			String sql = "delete from historico where id = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			statement.setInt(1, historico.getId());
			statement.execute();
		}
	
	public boolean existeNoBancoPorCpf(Aluno aluno) throws SQLException {
		
			
			String sql = "select * from cadastro where cpf = ?";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			
			statement.setString(1, aluno.getCpf());
			
			statement.execute();
			
			ResultSet resultSet = statement.getResultSet();
				
			return resultSet.next();	
		}
	
	
	
}
