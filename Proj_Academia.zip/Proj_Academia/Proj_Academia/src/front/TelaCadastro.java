package front;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import dao.Conexao;
import dao.UsuarioDao;
import model.Aluno;





public class TelaCadastro extends JFrame implements ActionListener{
	
	JLabel title;
    JLabel jLabelName;
    JLabel jLabelDataN;
    JLabel jLabelId;
    JLabel jLabelCpf;
    JLabel jLabelPeso;
    JLabel jLabelAltura;
    JTextField textId;
    JTextField textNome;
    JTextField textCpf;
    JTextField textDataN;
    JTextField textPeso;
    JTextField textAltura;

    RoundButton voltar;
    RoundButton salvar;
    

   
    public TelaCadastro() {
    	
    	
    	
    	JFrame jFrame = new JFrame();
		setTitle("Cadastrar");
	
        setSize(700,410);
        setDefaultCloseOperation(TelaCadastro.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);
        
        title = new JLabel("Cadastro");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBounds(275, 5, 300, 100);
                
        add(title);
       
        
        jLabelName = new JLabel("Nome completo:");
        jLabelName.setBounds(115, 75, 200, 50);
        jLabelName.setFont(new Font("Arial", Font.PLAIN, 14));
        
     
        add(jLabelName);
        
        textNome = new JTextField();
        textNome.setBounds(115, 115, 440, 30);
        textNome.setFont(new Font("Arial", Font.ITALIC, 15));
        
        add(textNome);
        
        jLabelCpf = new JLabel("CPF:");
        jLabelCpf.setBounds(115, 145, 200, 50);
        jLabelCpf.setFont(new Font("Arial", Font.PLAIN, 14));  
     
        add(jLabelCpf);
        
        textCpf = new JTextField();
        textCpf.setBounds(115, 185, 140, 30);
        textCpf.setFont(new Font("Arial", Font.ITALIC, 15));
        
        add(textCpf);
        
        
        jLabelDataN = new JLabel("Data de nascimento:");
        jLabelDataN.setBounds(280, 145, 250, 50);
        jLabelDataN.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelDataN);
        
        textDataN = new JTextField();
        textDataN.setBounds(280, 185, 140, 30);
        textDataN.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textDataN);
        
        jLabelPeso = new JLabel("Peso:");
        jLabelPeso.setBounds(115, 215, 250, 50);
        jLabelPeso.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelPeso);
        
        textPeso = new JTextField();
        textPeso.setBounds(115, 250, 70, 30);
        textPeso.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textPeso);
        
        jLabelAltura = new JLabel("Altura:");
        jLabelAltura.setBounds(210, 215, 250, 50);
        jLabelAltura.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelAltura);
        
        textAltura = new JTextField();
        textAltura.setBounds(210, 250, 70, 30);
        textAltura.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textAltura);
         
        
        voltar = new RoundButton("Voltar");
        voltar.setBounds(250, 310, 85, 25);
        add(voltar);
        
        voltar.addActionListener(this);
	    
        salvar = new RoundButton("Salvar");
        salvar.setBounds(365, 310, 85, 25);
        add(salvar);
        
        salvar.addActionListener(this);
        
        
        
        setVisible(true);
    }
    
    public JTextField getTextNome() {
		return textNome;
	}

	public void setTextNome(JTextField textNome) {
		this.textNome = textNome;
	}

	public JTextField getTextCpf() {
		return textCpf;
	}

	public void setTextCpf(JTextField textCpf) {
		this.textCpf = textCpf;
	}

	public JTextField getTextDataN() {
		return textDataN;
	}

	public void setTextDataN(JTextField textDataN) {
		this.textDataN = textDataN;
	}

	public JTextField getTextPeso() {
		return textPeso;
	}

	public void setTextPeso(JTextField textPeso) {
		this.textPeso = textPeso;
	}

	public JTextField getTextAltura() {
		return textAltura;
	}

	public void setTextAltura(JTextField textAltura) {
		this.textAltura = textAltura;
	}


	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == salvar){
			this.dispose();
			salvarAluno();		
		}

		if (event.getSource() == voltar){
			this.dispose();		
		}
	}
		
	public void salvarAluno() {	
		
		String nome = getTextNome().getText();
		String cpf = getTextCpf().getText();
		String dataNascimento = getTextDataN().getText();
		String peso = getTextPeso().getText();
		String altura = getTextAltura().getText();
		
		Aluno alunoNovo = new Aluno(nome, cpf, dataNascimento, peso, altura);
		
		try {
			Connection conexao = new Conexao().getConnection();
			UsuarioDao usuarioDao = new UsuarioDao(conexao);
			usuarioDao.insert(alunoNovo);
			
			JOptionPane.showMessageDialog(null, "Aluno salvo com sucesso!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	} 
	
	
	
	

}
