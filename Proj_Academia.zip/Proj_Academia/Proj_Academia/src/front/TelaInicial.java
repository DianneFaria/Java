package front;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


import dao.Conexao;
import dao.UsuarioDao;
import model.Aluno;

public class TelaInicial extends JFrame implements ActionListener {
		
	JLabel title;
    
    JLabel jLabelCpf;
    JLabel jLabelCadastrar;
    JTextField textCpfBusca;

    RoundButton buscar;
    RoundButton cadastrar;
    
    public static void main(String[] args) {
		 
		 new TelaInicial();
	 }
    
    private TelaUpdateDelete telaUpdateDelete = new TelaUpdateDelete();
    
    

    public void setTelaUpdateDelete(TelaUpdateDelete telaUpdateDelete) {
   	this.telaUpdateDelete = telaUpdateDelete;
   }
    
    
    private CadastroPeso cadastroPeso = new CadastroPeso();
    
	
    
	 public TelaInicial() {
		 
		 	telaUpdateDelete.setVisible(false);
		 	cadastroPeso.setVisible(false);
	    	   	
	    	JFrame jFrame = new JFrame();
			setTitle("Tela Inicial");
		
	        setSize(700,410);
	        setDefaultCloseOperation(TelaInicial.DISPOSE_ON_CLOSE);
	        setResizable(false);
	        setLocationRelativeTo(null);
	        setLayout(null);
	        
	        title = new JLabel("Seja Bem Vindo!");
	        title.setFont(new Font("Arial", Font.BOLD, 20));
	        title.setBounds(255, 10, 300, 100);
	                
	        add(title);
	                
	     
	        jLabelCpf = new JLabel("Busque o CPF do aluno abaixo:");
	        jLabelCpf.setBounds(230, 115, 200, 50);
	        jLabelCpf.setFont(new Font("Arial", Font.PLAIN, 14));
	        
	     
	        add(jLabelCpf);
	        
	        textCpfBusca = new JTextField();
	        textCpfBusca.setBounds(230, 160, 200, 30);
	        textCpfBusca.setFont(new Font("Arial", Font.ITALIC, 15));
	        
	        add(textCpfBusca);
	         
	        
	        buscar = new RoundButton("Buscar");
	        buscar.setBounds(290, 205, 75, 25);
	        add(buscar);
	        
	        buscar.addActionListener(this);
	        
	        jLabelCadastrar = new JLabel("Caso não tenha um registro, clique em:");
	        jLabelCadastrar.setBounds(155, 300, 350, 30);
	        jLabelCadastrar.setFont(new Font("Arial", Font.PLAIN, 14));
	             
	        add(jLabelCadastrar);
		    
	        cadastrar = new RoundButton("Cadastrar");
	        cadastrar.setBounds(410, 302, 91, 25);
	        add(cadastrar);
	        
	        cadastrar.addActionListener(this);
	        
	        	        
	        setVisible(true);
	        
	    }
	 	 
	 
	 public JTextField getTextCpfBusca() {
		return textCpfBusca;
	}

	public void setTextCpfBusca(JTextField textCpfBusca) {
		this.textCpfBusca = textCpfBusca;
	}
	


	 public void actionPerformed(ActionEvent event) {
		 
			if (event.getSource() == buscar){
				try {
					autenticar();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			if (event.getSource() == cadastrar){
				new TelaCadastro();
			}

			
		}
	 
	 
	 public boolean autenticar() throws SQLException {
			
			//Buscar um usuario da view
			
			String cpf = getTextCpfBusca().getText();

			
			Aluno alunoAutenticar = new Aluno(cpf);
			
			//Verificar se existe no banco de dados
			
	        Conexao dbConnection = new Conexao();
	        Connection conexao = dbConnection.getConnection();

	        // Create an instance of UsuarioDao using the connection
	        UsuarioDao usuarioDao = new UsuarioDao(conexao);

			
			boolean existe = usuarioDao.existeNoBancoPorCpf(alunoAutenticar);
			
			//Verifica se existe
			
			if(existe) {			
				telaUpdateDelete.setCpfPesquisado(cpf);
				cadastroPeso.setCpfPesquisado(cpf);
				telaUpdateDelete.setCadastroPeso(cadastroPeso);
				telaUpdateDelete.mostrarRegistro();
				telaUpdateDelete.setVisible(true);
	           
			}else {
				JOptionPane.showMessageDialog(null, "Aluno não existe, faça o cadastro.");
			}
			return existe;	
		}

}
