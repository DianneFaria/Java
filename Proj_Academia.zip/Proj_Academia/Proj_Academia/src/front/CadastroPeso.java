package front;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dao.Conexao;
import dao.UsuarioDao;
import model.Aluno;
import model.Historico;

public class CadastroPeso extends JFrame implements ActionListener {
	
	JLabel title;  
    JLabel jLabelData;
    JLabel jLabelPeso;
    JLabel jLabelId;
    
    JTextField textData;
    JTextField textPeso;
    JTextField textId;

    RoundButton atualizar;
    RoundButton deletar;
    RoundButton cadastrar;
    RoundButton verHistorico;
    RoundButton imc;
    
    String cpf;
    String nome;
    String altura;
    
    TabelaHistorico tabelaHistorico = new TabelaHistorico();
    
    public void setTabelaHistorico(TabelaHistorico tabelaHistorico) {
		this.tabelaHistorico = tabelaHistorico;
	}
    
	
	public CadastroPeso() {
		     	   	
	    	JFrame jFrame = new JFrame();
			setTitle("Registro de peso");
		
	        setSize(700,410);
	        setDefaultCloseOperation(TelaInicial.DISPOSE_ON_CLOSE);
	        setResizable(false);
	        setLocationRelativeTo(null);
	        setLayout(null);
	        
	        title = new JLabel("Registro de peso");
	        title.setFont(new Font("Arial", Font.BOLD, 20));
	        title.setBounds(255, 10, 300, 100);
	                
	        add(title);
	        
	        jLabelId = new JLabel("ID:");
	        jLabelId.setBounds(270, 95, 40, 30);
	        jLabelId.setFont(new Font("Arial", Font.PLAIN, 14));
	             
	        add(jLabelId);
	        
	        textId = new JTextField();
	        textId.setBounds(270, 120, 40, 25);
	        textId.setFont(new Font("Arial", Font.ITALIC, 15));
	        
	        add(textId);
	                
	     
	        jLabelData = new JLabel("Data:");
	        jLabelData.setBounds(270, 150, 40, 30);
	        jLabelData.setFont(new Font("Arial", Font.PLAIN, 14));
	        
	     
	        add(jLabelData);
	        
	        textData = new JTextField();
	        textData.setBounds(270, 175, 130, 25);
	        textData.setFont(new Font("Arial", Font.ITALIC, 15));
	        
	        add(textData);
	        
	        jLabelPeso = new JLabel("Peso:");
	        jLabelPeso.setBounds(270, 205, 40, 30);
	        jLabelPeso.setFont(new Font("Arial", Font.PLAIN, 14));
	        
	     
	        add(jLabelPeso);
	        
	        textPeso = new JTextField();
	        textPeso.setBounds(270, 230, 130, 25);
	        textPeso.setFont(new Font("Arial", Font.ITALIC, 15));
	        
	        add(textPeso);
	                 
	        
	        atualizar = new RoundButton("Atualizar");
	        atualizar.setBounds(190, 300, 84, 25);
	        add(atualizar);
	        
	        atualizar.addActionListener(this);
	        
	        
	        cadastrar = new RoundButton("Cadastrar");
	        cadastrar.setBounds(290, 300, 91, 25);
	        add(cadastrar);
	        
	        cadastrar.addActionListener(this);
	        
	        deletar = new RoundButton("Deletar");
	        deletar.setBounds(397, 300, 75, 25);
	        add(deletar);
	        
	        deletar.addActionListener(this);
	        
	        verHistorico = new RoundButton("Ver histórico");
	        verHistorico.setBounds(565, 10, 107, 25);
	        add(verHistorico); 
	        
	        verHistorico.addActionListener(this);
	        
	        imc = new RoundButton("Gerar IMC");
	        imc.setBounds(580, 335, 90, 25);
	        add(imc);
	        
	        imc.addActionListener(this);
	        
	        	        
	        setVisible(true);
	    }
	
	
	public void setCpfPesquisado(String e) {
		cpf = e;
	}
	
	public void setNome(String n) {
		nome = n;
	}
	
	public void setAltura(String a) {
		altura = a;
	}
	
	
	
	public void atualizarHistorico() {	
		
		String idTexto = textId.getText();
		int id = Integer.parseInt(idTexto);
		
		String peso = textPeso.getText();
		String dataHistorico = textData.getText();

		
		Historico historicoAtualizado = new Historico(id, peso, dataHistorico);
		
		try {
			Connection conexao = new Conexao().getConnection();
			UsuarioDao usuarioDao = new UsuarioDao(conexao);
			usuarioDao.updateHistorico(historicoAtualizado);
			
			JOptionPane.showMessageDialog(null, "Histórico atualizado com sucesso!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	} 
	
	public void salvarHistorico() {	
			
			String peso = textPeso.getText();
			String dataHistorico = textData.getText();
			
			Historico novoHistorico = new Historico(cpf, peso, dataHistorico);
			
			try {
				Connection conexao = new Conexao().getConnection();
				UsuarioDao usuarioDao = new UsuarioDao(conexao);
				usuarioDao.insertHistorico(novoHistorico);
				
				JOptionPane.showMessageDialog(null, "Histórico salvo com sucesso!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		} 
	
	
	public void deletarHistorico() {	
			
			String idTexto = textId.getText();

			int id = Integer.parseInt(idTexto);
		
			Historico deletaHistorico = new Historico(id);
			
			try {
				Connection conexao = new Conexao().getConnection();
				UsuarioDao usuarioDao = new UsuarioDao(conexao);
				usuarioDao.deleteHistorico(deletaHistorico);
				
				JOptionPane.showMessageDialog(null, "Histórico excluído com sucesso!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		} 
	

	
	
	public void salvarNaTabela() {
			
			try {
			Connection conexao = new Conexao().getConnection();
			PreparedStatement stmt = conexao.prepareStatement("select * from historico");
			
			ResultSet rs = stmt.executeQuery();
	
			tabelaHistorico.dados = new ArrayList<>();
			while (rs.next()) {
			 int id = rs.getInt("id");
			 String cpfBanco = rs.getString("cpf");
			 String peso = rs.getString("peso");
			 String dataHistorico = rs.getString("dataHistorico");	
	
				if (cpfBanco.equals(cpf)) {
					tabelaHistorico.dados.add(new Historico(id,peso, dataHistorico));
				}
			   
			}
			stmt.close();
			conexao.close();
			tabelaHistorico.setTabelaHistorico(tabelaHistorico);
			tabelaHistorico.gerarTabela();
			tabelaHistorico.setVisible(true);
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();		
			}			
		}
	
	public void gerarImc() {
		
		String peso = textPeso.getText().replace(',', '.');
		double pesoDouble = Double.parseDouble(peso);
		
		double alturaDouble = Double.parseDouble(altura.replace(',', '.'));
		
		String data = textData.getText();
		
		double imc = pesoDouble / (alturaDouble * alturaDouble);
		
		try{
            FileWriter fw = new FileWriter("C:\\Users\\diann\\OneDrive\\Área de Trabalho\\IMC.txt", true);
            BufferedWriter escrita = new BufferedWriter(fw);
            
            escrita.write("\n");
            escrita.write("\nCálculo de IMC! \n");
            escrita.write("\n");
            escrita.write("Data: " +data+ "\n");
            escrita.write("CPF: " + cpf+ "\n");
            escrita.write("Nome: " +nome+ "\n");
            escrita.write("IMC: " +imc+ "\n");
            
            if(imc < 18.5) {
            	escrita.write("Relatório: De acordo com seu IMC você está abaixo do peso.");
            }
            else if(imc >= 18.5 && imc <= 24.9) {
            	escrita.write("Relatório: De acordo com seu IMC você está com peso saudável.");
            }
            else if(imc >= 25 && imc <= 29.9) {
            	escrita.write("Relatório: De acordo com seu IMC você está com sobrepeso.");
            }
            else if(imc >= 30 && imc <= 39.9) {
            	escrita.write("Relatório: De acordo com seu IMC você está obeso.");
            }
            else {
            	escrita.write("Relatório: De acordo com seu IMC você está com obesidade mórbida.");
            }
                   
            escrita.close();
            JOptionPane.showMessageDialog(null, "Arquivo IMC gerado com sucesso! \nVá até a área de trabalho para conferir.");
        }
         catch(IOException ex){
            System.out.println("\n Problemas ao abrir o arquivo!");
        }
	}
		


	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == atualizar){
			atualizarHistorico();		
		}

		if (event.getSource() == cadastrar){
			salvarHistorico();
		}
		
		if (event.getSource() == deletar){
			deletarHistorico();
		}
		
		if (event.getSource() == verHistorico){
			salvarNaTabela();
		}
		
		if (event.getSource() == imc){
			gerarImc();
		}
	}

}
