package front;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dao.Conexao;
import dao.UsuarioDao;
import model.Aluno;


public class TelaUpdateDelete extends JFrame implements ActionListener{
	
	JLabel title;
    JLabel jLabelName;
    JLabel jLabelDataN;
    JLabel jLabelCpf;
    JLabel jLabelPeso;
    JLabel jLabelAltura;
    JTextField textNome;
    JTextField textCpf;
    JTextField textDataN;
    JTextField textPeso;
    JTextField textAltura;

    RoundButton update;
    RoundButton delete;
    RoundButton historico;
    
    String cpfPesquisado;
    
	private CadastroPeso cadastroPeso;
		
	public void setCadastroPeso(CadastroPeso cadastroPeso) {
		this.cadastroPeso = cadastroPeso;
	}
		
		
	TelaInicial telaInicial;
   
    public TelaUpdateDelete() {
    	
    	
    	
    	JFrame jFrame = new JFrame();
		setTitle("Registro");
	
        setSize(700,410);
        setDefaultCloseOperation(TelaUpdateDelete.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);
        
        title = new JLabel("Registro");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBounds(295, 5, 300, 100);
                
        add(title);
                     
     
        jLabelName = new JLabel("Nome completo:");
        jLabelName.setBounds(115, 75, 200, 50);
        jLabelName.setFont(new Font("Arial", Font.PLAIN, 14));
        
     
        add(jLabelName);
        
        textNome = new JTextField();
        textNome.setBounds(115, 115, 440, 30);
        textNome.setFont(new Font("Arial", Font.ITALIC, 15));
        
        add(textNome);
        
        jLabelCpf = new JLabel("CPF:");
        jLabelCpf.setBounds(115, 145, 200, 50);
        jLabelCpf.setFont(new Font("Arial", Font.PLAIN, 14));  
     
        add(jLabelCpf);
        
        textCpf = new JTextField();
        textCpf.setBounds(115, 185, 140, 30);
        textCpf.setFont(new Font("Arial", Font.ITALIC, 15));
        
        add(textCpf);
        
        
        jLabelDataN = new JLabel("Data de nascimento:");
        jLabelDataN.setBounds(280, 145, 250, 50);
        jLabelDataN.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelDataN);
        
        textDataN = new JTextField();
        textDataN.setBounds(280, 185, 140, 30);
        textDataN.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textDataN);
        
        jLabelPeso = new JLabel("Peso:");
        jLabelPeso.setBounds(115, 215, 250, 50);
        jLabelPeso.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelPeso);
        
        textPeso = new JTextField();
        textPeso.setBounds(115, 250, 70, 30);
        textPeso.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textPeso);
        
        jLabelAltura = new JLabel("Altura:");
        jLabelAltura.setBounds(210, 215, 250, 50);
        jLabelAltura.setFont(new Font("Arial", Font.PLAIN, 14));
                 
        add(jLabelAltura);
        
        textAltura = new JTextField();
        textAltura.setBounds(210, 250, 70, 30);
        textAltura.setFont(new Font("Arial", Font.ITALIC, 15));
                
        add(textAltura);
         
        
        update = new RoundButton("Atualizar cadastro");
        update.setBounds(210, 310, 138, 25);
        add(update);
        
        update.addActionListener(this);
	    
        delete = new RoundButton("Deletar cadastro");
        delete.setBounds(365, 310, 129, 25);
        add(delete);
        
        delete.addActionListener(this);
        
        historico = new RoundButton("Histórico de peso");
        historico.setBounds(540, 10, 133, 25);
        add(historico); 
        
        historico.addActionListener(this);
              
        setVisible(true);
    }
    
    public JTextField getTextNome() {
		return textNome;
	}

	public void setTextNome(JTextField textNome) {
		this.textNome = textNome;
	}

	public JTextField getTextCpf() {
		return textCpf;
	}

	public void setTextCpf(JTextField textCpf) {
		this.textCpf = textCpf;
	}

	public JTextField getTextDataN() {
		return textDataN;
	}

	public void setTextDataN(JTextField textDataN) {
		this.textDataN = textDataN;
	}

	public JTextField getTextPeso() {
		return textPeso;
	}

	public void setTextPeso(JTextField textPeso) {
		this.textPeso = textPeso;
	}

	public JTextField getTextAltura() {
		return textAltura;
	}

	public void setTextAltura(JTextField textAltura) {
		this.textAltura = textAltura;
	}

	
	public void setCpfPesquisado(String e) {
		cpfPesquisado = e;
	}
	
	
	public void mostrarRegistro() {
			
			try {
			Connection conexao = new Conexao().getConnection();
			PreparedStatement stmt = conexao.prepareStatement("select * from cadastro");
			
			ResultSet rs = stmt.executeQuery();
	
			while (rs.next()) {
				
				String cpfBusca = rs.getString("cpf");
				
				if (cpfBusca.equals(cpfPesquisado)) {
					
					String nome = rs.getString("nome");
					 textNome.setText(nome);
					 
					 textCpf.setText(cpfBusca);
					 
					 String dataNascimento = rs.getString("dataNascimento");
					 textDataN.setText(dataNascimento);
					 
					 String peso = rs.getString("peso");
					 textPeso.setText(peso);
					 
					 String altura = rs.getString("altura");
					 textAltura.setText(altura);					
				}		   
			}
			stmt.close();
			conexao.close();
			} catch (SQLException e) {				
				// TODO Auto-generated catch block
				e.printStackTrace();				
			}					
	}
	
	
	public void deletarAluno() {	
		
		String cpf = getTextCpf().getText();
		
		Aluno deletaAluno = new Aluno(cpf);
		
		try {
			Connection conexao = new Conexao().getConnection();
			UsuarioDao usuarioDao = new UsuarioDao(conexao);
			usuarioDao.delete(deletaAluno);
			
			JOptionPane.showMessageDialog(null, "Aluno excluído com sucesso!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	} 

	public void atualizarAluno() {	
			
			String nome = getTextNome().getText();
			String cpf = getTextCpf().getText();
			String dataNascimento = getTextDataN().getText();
			String peso = getTextPeso().getText();
			String altura = getTextAltura().getText();
			
			Aluno atualizaAluno = new Aluno(nome, cpf, dataNascimento, peso, altura);
			
			try {
				Connection conexao = new Conexao().getConnection();
				UsuarioDao usuarioDao = new UsuarioDao(conexao);
				usuarioDao.update(atualizaAluno);
				
				JOptionPane.showMessageDialog(null, "Aluno atualizado com sucesso!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		} 
	
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == update){
			this.dispose();
			atualizarAluno();		
		}

		if (event.getSource() == delete){
			this.dispose();
			deletarAluno();
		}
		
		if (event.getSource() == historico){
			this.dispose();
			String nome = getTextNome().getText();
			String altura = getTextAltura().getText();
			cadastroPeso.setNome(nome);
			cadastroPeso.setAltura(altura);
			cadastroPeso.setVisible(true);
		}
	}
}

