/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package turma;

/**
 *
 * @author Manhã
 */
public class Teste {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Aluno aluno1;
        Data data1;
        
        data1 = new Data(12,02,2002);
        
        aluno1 = new Aluno(123456, "João", 'm', "12345", "142536", data1);
      
     
        aluno1.imprimir();
   
       
    }
    
    
    
    
}
