/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio06;

import java.util.Scanner;

/**
 *
 * @author Manhã
 */
public class Exercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        int vetor[] = {2,5,4,54,43,22,5,9,30,15};
        int i;
        int posicao = -1;
        
        System.out.println("Digite um número para procurar no vetor: ");
        int numero = ler.nextInt();
        
        for(i=0; i<10; i++){
            if(numero == vetor[i]){
                posicao = i;
                break;
            }
            
        }
        
        if (posicao != -1){
            System.out.println("O número foi encontrado na posição [" + posicao + "] do vetor.");
        } 
        else{
            System.out.println("O número não foi encontrado em nenhuma posição do vetor.");
        }
    }
        
    
}
