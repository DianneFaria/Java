/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio05;

import java.util.Scanner;

/**
 *
 * @author Manhã
 */
public class Exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        int n = 8;
        int vetor[] = new int[n];
        int i;
        
        for(i=0; i<n; i++){
            System.out.printf("Insira %d valor de %d: ", (i+1), n);
            vetor[i] = ler.nextInt();
        }
        
        for(i = n/2; i < n; i++){
            System.out.println(vetor[i]);
        }
        
        for(i=0; i< n/2; i++){
            System.out.println(vetor[i]);
        }
    }
    
}
