/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio08;

/**
 *
 * @author Manhã
 */
public class Exercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int m[] = {1,2,3,4,5,6,7,8,9,10};
        int n[] = {1,1,1,1,1,1,1,1,1,1};
        int i;
        int multi;
        int soma = 0;
        
        for(i=0; i<10; i++){
            multi = m[i] * n[i];
            soma = soma + multi;
        }
        System.out.println("O produto escalar de M por N é: " + soma);
        
    }
    
}
