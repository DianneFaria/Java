/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio07;

/**
 *
 * @author Manhã
 */
public class Exercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a[] = {1,2,4,6,21};
        int b[] = {2,3,6,7,9,11,15,20};
        int i;
        int j;
        
        for(i=0; i<8;i++){
            for(j=0; j<5;j++){
                if(b[i] == a[j]){
                    System.out.println(a[j]);
                    break;
                }
            }
        
        }
    }
    
}
