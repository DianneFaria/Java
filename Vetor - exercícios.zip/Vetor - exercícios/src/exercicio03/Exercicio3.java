/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio03;

import java.util.Scanner;

/**
 *
 * @author Manhã
 */
public class Exercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        int n= 10;
        int vetor[] = new int[n];
        int i;
        int contador =0;
        int soma = 0;
        int maiorValor = Integer.MIN_VALUE;
        
        for(i=0; i < 10; i++){
            System.out.printf("Insira %d valor de %d: ", (i+1), n);
            int valor = ler.nextInt();
            if(valor % 2 == 0){
                vetor[i] = valor;
                contador++;
                soma = soma + valor;
                if(valor > maiorValor){
                    maiorValor = valor;
                }
            }
        }
        System.out.println("Quantidade:" + contador );
        System.out.println("Maior valor encontrador: " +maiorValor);
        System.out.println("Média: " + (double) soma / contador);
    }
    
}
