/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio04;

import java.util.Scanner;

/**
 *
 * @author Manhã
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
        int i;
        
        System.out.println("Insira a quantidade de números que serão digitados: ");
        int n = ler.nextInt();
        
        int vetor[] = new int [n];
        
        for(i=0; i<n; i++){
            System.out.printf("Insira %d valor de %d: ", (i+1), n);
            vetor[i] = ler.nextInt();
        }
        
        System.out.println("Sequência na ordem inversa:");
        
        for(i= n -1; i>=0; i--){
            System.out.print(vetor[i] + " ");
        }
    }
    
}
