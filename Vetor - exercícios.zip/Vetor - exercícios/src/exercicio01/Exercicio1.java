/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio01;

import java.util.Scanner;

/**
 *
 * @author Manhã
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner ler = new Scanner(System.in);
        int n = 10;
        int vetor[]= new int [n];
        int i;
        
        for(i=0; i<10; i++){
            System.out.printf("Informe %do valor de %d: ", (i+1), n);
            vetor[i] = ler.nextInt();
        }
        
        for(i=0; i<10; i++){
            System.out.print(vetor[i]);
        }
        
        
    }
    
}
