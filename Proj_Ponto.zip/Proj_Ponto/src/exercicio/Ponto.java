/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio;

/**
 *
 * @author Manhã
 */
public class Ponto extends ProjPonto{
    
    private int x;
    private int y;

    public Ponto(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
     
    
    public double calcularDistancia(Ponto ponto1, Ponto ponto2){
        
        double distanciaX = ponto2.getX() - ponto1.getX();
        double distanciaY = ponto2.getY() - ponto1.getY();
        double distancia = Math.sqrt(Math.pow(distanciaX, 2) + Math.pow(distanciaY, 2));
        
        return distancia;

    }
    
}
