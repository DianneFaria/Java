/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proj_pedido;

/**
 *
 * @author Manhã
 */
public class Proj_Pedido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Item it1, it2, it3;
        it1 = new Item(100,3,3);
        it2 = new Item(101,2,4);
        it3 = new Item(102,1,5);
        
        Data dCompra1, dCompra2, dCompra3;
        dCompra1 = new Data (13,02,2022);
        dCompra2 = new Data (18,10,2021);
        dCompra3 = new Data (10,05,2023);
        
        Data dNiver1, dNiver2, dNiver3;
        dNiver1 = new Data (11,02,2000);
        dNiver2 = new Data (15,10,2001);
        dNiver3 = new Data (01,05,2003);
        
        Cliente cliente1, cliente2, cliente3;
        cliente1 = new Cliente("Ana", 123456, dNiver1);
        cliente2 = new Cliente("Dianne", 165432, dNiver2);
        cliente3 = new Cliente("Joao", 6521, dNiver3);
        
        Pedido pedido1 = new Pedido(1001,cliente1, dCompra1);
        
        pedido1.adicionaItem(it1);
        pedido1.adicionaItem(it2);
        pedido1.adicionaItem(it3);
        pedido1.imprimir();
        
        pedido1.removeItem(it3);
        pedido1.imprimir();
    }
    
    
}
